<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AssetsImages extends Model
{
  public $timestamps = true;
  protected $table = 'assets_images';
}
